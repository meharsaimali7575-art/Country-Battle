COUNTRY BATTLE — ANDROID PROJECT (UPDATED SOURCE)

IS UPDATE MEIN
- Android app ab startup par dashboard ki bajaye seedha Country Battle game (/game) kholta hai.
- Top bar mein hamburger (☰) menu hai: Dashboard, Live Screen aur YouTube Bridge.
- Game page load hone ke baad local YouTube bridge ka EventSource/API connection automatically attempt hota hai.
- Agar bridge ke paas pehle se valid OAuth tokens aur server configuration ho, to Node server startup par active YouTube Live Chat dhoondhna shuru karta hai aur reconnect retry karta hai.
- ARM64 launcher icon ke liye Country Battle vector logo add kiya gaya hai.
- GitHub Actions workflow mein Node.js aur game JavaScript syntax validation add hai.
- Existing game HTML, flags, collision/physics, support commands, voice prompts, winner announcement, audio toggles aur package/application ID preserve kiye gaye hain.
- Mobile par Flag Arena apni fixed jagah rehta hai; neeche Game Control panel apne alag scroll area mein move hota hai, is liye panel scroll karne se arena saath nahi hilta.
- Flag Speed control ab smooth range slider hai: 0.5x se 2.5x tak 0.1x steps mein speed kam/zyada ki ja sakti hai.

IMPORTANT — OAUTH KI SECURITY / REMAINING WORK
Is source ZIP mein OAuth ka secure in-app credential editor abhi complete nahin hai. Google Web Application Client Secret ko APK, WebView localStorage, ya plain app file mein rakhna safe nahin hota. Current bridge ab bhi GOOGLE_CLIENT_ID aur GOOGLE_CLIENT_SECRET ko private runtime .env se read karta hai aur callback http://localhost:8787/auth/callback use karta hai. Settings screen is limitation ko clearly batati hai aur Google authorization ka existing endpoint deti hai.

Is liye is build ko full production-ready YouTube OAuth solution na samjhein: secure Android Keystore credential hand-off / native Android OAuth with PKCE ya trusted server-side OAuth broker implement aur Google Cloud Console par configure karna abhi baqi hai. Existing Web Application OAuth client ka secret APK mein hardcode nahin kiya gaya.

BUILD VIA GITHUB ACTIONS
1. ZIP extract karein aur project ke andar ka tamam content GitHub repository ke root par upload karein.
2. GitHub > Actions > Country Battle Android APK kholein.
3. Run workflow select karein.
4. Build successful ho to Artifacts se country-battle-debug-apk download karein; us ZIP mein app-debug.apk hoga.

LOCAL BUILD (PC par)
Requirements: JDK 17, Android SDK 35, NDK 27.2.12479018, CMake 3.22.1, Gradle 8.9, Node.js/npm.

  bash scripts/setup-node-mobile.sh
  bash scripts/setup-node-deps.sh
  gradle --no-daemon assembleDebug

APK output:
  app/build/outputs/apk/debug/app-debug.apk

TECHNICAL NOTES
- Package/application ID: com.countrybattle.mobile
- ABI: arm64-v8a only
- Embedded Node.js Mobile v18.20.4 is downloaded by CI; runtime binaries are not committed in this source ZIP.
- Node server binds to 127.0.0.1:8787. App health endpoint: /health.
- The app process hosts Node.js; Android may terminate it if the app is force-stopped or the OS reclaims the process. A persistent foreground service has not been implemented, so background survival is not guaranteed.
- Build success and real-device touch/audio/OAuth tests must be confirmed by running the GitHub Actions workflow and installing the resulting APK on an ARM64 Android phone.
