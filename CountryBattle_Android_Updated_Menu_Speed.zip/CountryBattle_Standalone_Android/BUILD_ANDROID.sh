#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
: "${ANDROID_NDK_HOME:=${ANDROID_NDK_ROOT:-}}"
if [[ -z "$ANDROID_NDK_HOME" ]]; then
  echo 'ANDROID_NDK_HOME is not set. Use GitHub Actions workflow or install an Android NDK.' >&2
  exit 2
fi
export ANDROID_NDK_HOME
command -v node >/dev/null && command -v npm >/dev/null || { echo 'Node.js/npm are required.' >&2; exit 2; }
command -v gradle >/dev/null || { echo 'Gradle 8.9 is required.' >&2; exit 2; }
./scripts/setup-node-mobile.sh
./scripts/setup-node-deps.sh
gradle --no-daemon --stacktrace assembleDebug
