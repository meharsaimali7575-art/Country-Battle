package com.countrybattle.mobile;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.graphics.Typeface;
import android.content.Intent;
import android.net.Uri;
import android.content.res.AssetManager;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends Activity {
    static { System.loadLibrary("node"); System.loadLibrary("native-lib"); }
    private static volatile boolean nodeStarted = false;
    private WebView webView;
    private TextView status;
    private LinearLayout drawer;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private String currentPage = "game";

    public native int startNodeWithArguments(String[] arguments);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(8, 18, 38));
        getWindow().setNavigationBarColor(Color.BLACK);
        buildUi();
        startEmbeddedNode();
        waitForServer(0);
    }

    private Button menuButton(String label, String path) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setGravity(Gravity.CENTER_VERTICAL);
        b.setBackgroundColor(Color.rgb(15, 35, 68));
        b.setOnClickListener(v -> { drawer.setVisibility(View.GONE); navigate(path); });
        return b;
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(8, 18, 38));

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(8, 4, 8, 4);
        Button hamburger = new Button(this);
        hamburger.setText("☰"); hamburger.setTextSize(24); hamburger.setTextColor(Color.WHITE);
        hamburger.setBackgroundColor(Color.TRANSPARENT);
        hamburger.setContentDescription("Open navigation menu");
        hamburger.setOnClickListener(v -> drawer.setVisibility(drawer.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE));
        TextView brand = new TextView(this);
        brand.setText("COUNTRY BATTLE"); brand.setTextColor(Color.rgb(100, 246, 255));
        brand.setTextSize(18); brand.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        brand.setPadding(12, 0, 0, 0);
        bar.addView(hamburger, new LinearLayout.LayoutParams(56, 52));
        bar.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));

        status = new TextView(this); status.setTextColor(Color.WHITE); status.setPadding(12, 3, 12, 7); status.setText("Starting Country Battle…");
        drawer = new LinearLayout(this);
        drawer.setOrientation(LinearLayout.VERTICAL);
        drawer.setPadding(8, 8, 8, 8);
        drawer.setBackgroundColor(Color.rgb(7, 22, 50));
        drawer.setVisibility(View.GONE);
        TextView drawerTitle = new TextView(this); drawerTitle.setText("COUNTRY BATTLE MENU"); drawerTitle.setTextColor(Color.rgb(100,246,255)); drawerTitle.setTextSize(16); drawerTitle.setPadding(12,12,12,12);
        drawer.addView(drawerTitle);
        drawer.addView(menuButton("🏠  Dashboard", "/"));
        drawer.addView(menuButton("▶  Live Screen", "/game?live=1"));
        drawer.addView(menuButton("🔴  YouTube Bridge", "/"));

        webView = new WebView(this);
        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true); ws.setDomStorageEnabled(true); ws.setMediaPlaybackRequiresUserGesture(false);
        ws.setAllowFileAccess(false); ws.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("accounts.google.com".equals(uri.getHost()) || "oauth2.googleapis.com".equals(uri.getHost())) {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri)); return true;
                }
                return false;
            }
        });
        root.addView(bar); root.addView(drawer); root.addView(status);
        root.addView(webView, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
    }

    private void navigate(String path) {
        currentPage = path;
        webView.loadUrl("http://127.0.0.1:8787" + path);
    }

    private void startEmbeddedNode() {
        if (nodeStarted) return;
        nodeStarted = true;
        new Thread(() -> {
            try {
                File nodeDir = new File(getFilesDir(), "nodejs-project");
                copyAssetTree(getAssets(), "nodejs-project", nodeDir);
                String bootstrap = new File(nodeDir, "bootstrap.js").getAbsolutePath();
                startNodeWithArguments(new String[]{"node", bootstrap});
            } catch (Exception e) {
                nodeStarted = false;
                handler.post(() -> status.setText("Node.js startup failed: " + e.getMessage()));
            }
        }, "country-battle-node").start();
    }

    private void copyAssetTree(AssetManager assets, String path, File out) throws Exception {
        String[] children = assets.list(path);
        if (children == null || children.length == 0) {
            File parent = out.getParentFile(); if (parent != null) parent.mkdirs();
            try (InputStream in = assets.open(path); FileOutputStream fos = new FileOutputStream(out)) {
                byte[] buffer = new byte[8192]; int n; while ((n = in.read(buffer)) > 0) fos.write(buffer, 0, n);
            }
            return;
        }
        if (!out.exists()) out.mkdirs();
        for (String child : children) copyAssetTree(assets, path + "/" + child, new File(out, child));
    }

    private void waitForServer(int attempt) {
        new Thread(() -> {
            boolean ok = false;
            try { HttpURLConnection c = (HttpURLConnection) new URL("http://127.0.0.1:8787/health").openConnection(); c.setConnectTimeout(700); c.setReadTimeout(700); ok = c.getResponseCode() == 200; c.disconnect(); } catch (Exception ignored) {}
            final boolean ready = ok;
            handler.post(() -> {
                if (ready) { status.setText("● Local game and bridge service running"); navigate("/game"); }
                else if (attempt < 60) { status.setText("Starting embedded game service… " + (attempt + 1)); handler.postDelayed(() -> waitForServer(attempt + 1), 500); }
                else status.setText("Service did not start. Check the ARM64 Node runtime build.");
            });
        }, "country-battle-health").start();
    }

    @Override public void onBackPressed() {
        if (drawer != null && drawer.getVisibility() == View.VISIBLE) { drawer.setVisibility(View.GONE); return; }
        if (webView != null && webView.canGoBack()) webView.goBack(); else if (!"/game".equals(currentPage)) navigate("/game"); else super.onBackPressed();
    }
}
