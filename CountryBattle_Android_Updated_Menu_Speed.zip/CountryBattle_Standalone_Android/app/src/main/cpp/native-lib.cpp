#include <jni.h>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>
#include "node.h"

extern "C" JNIEXPORT jint JNICALL
Java_com_countrybattle_mobile_MainActivity_startNodeWithArguments(
        JNIEnv *env, jobject /* thiz */, jobjectArray arguments) {
    const jsize count = env->GetArrayLength(arguments);
    std::vector<std::string> values;
    std::vector<char*> argv;
    values.reserve(count);
    argv.reserve(count);
    for (jsize i = 0; i < count; ++i) {
        auto item = static_cast<jstring>(env->GetObjectArrayElement(arguments, i));
        const char *utf = env->GetStringUTFChars(item, nullptr);
        values.emplace_back(utf ? utf : "");
        if (utf) env->ReleaseStringUTFChars(item, utf);
        env->DeleteLocalRef(item);
    }
    for (auto &value : values) argv.push_back(value.data());
    return static_cast<jint>(node::Start(static_cast<int>(argv.size()), argv.data()));
}
