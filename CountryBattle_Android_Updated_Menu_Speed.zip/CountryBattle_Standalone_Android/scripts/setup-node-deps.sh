#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
NODE_DIR="$ROOT/app/src/main/assets/nodejs-project"
cd "$NODE_DIR"
node --version
npm --version
npm ci --omit=dev --no-audit --no-fund
node --check server.js
